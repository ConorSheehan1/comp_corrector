#include <stdio.h>
int main()
{
    // expect compiler error
    printf("Hello World\n";
    return 0;
}